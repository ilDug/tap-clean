# script

to generate the `*.mod_kicad` and `*.wrlt` files in this repository all you need to do is:

    bash generate.sh

## dependencies

* python
    * jinja2
* mashlab
* openscad
